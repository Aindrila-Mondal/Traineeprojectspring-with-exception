package com.cg.trainee.service;

import java.util.List;

import com.cg.exceptions.TraineeException;
import com.cg.trainee.bean.TraineeBean;

public interface ITraineeService {
	public TraineeBean addTrainee(TraineeBean trainee) throws TraineeException;
	public List<TraineeBean> getAllTraineeDetails() ;
	public TraineeBean getaTraineeDetails(int traineeId) ;
	public boolean deleteTrainee(int traineeId) ;
	public TraineeBean updatingTrainee(int traineeId,TraineeBean Trainee) ;
	
}
