package com.cg.trainee.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.exceptions.TraineeException;
import com.cg.trainee.bean.TraineeBean;
@Repository
public class ITraineeDaoImpl implements ITraineeDao{
	
		
		@PersistenceContext
		private EntityManager entityManager;

	



	@Override
	public TraineeBean addTrainee(TraineeBean trainee) throws TraineeException
	{
		try
		{
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}
		catch(Exception e)
		{
			throw new TraineeException("Exception in dao"+e.getMessage());
		}
	}

	@Override
	public List<TraineeBean> getAllTraineeDetails() {
		
		
			TypedQuery<TraineeBean> query = entityManager.createQuery("SELECT d FROM TraineeBean d", TraineeBean.class);
			return query.getResultList();

		
	}

	@Override
	public TraineeBean getaTraineeDetails(int traineeId){

		
		TraineeBean trainee=(TraineeBean)entityManager.find(TraineeBean.class, traineeId);
		
		return trainee;
	
	}

	@Override
	public boolean deleteTrainee(int traineeId)  {
	
		TraineeBean trainee=(TraineeBean)entityManager.find(TraineeBean.class, traineeId);
         
	        //Call remove method to remove the entity
	        if(trainee != null){
	        	entityManager.remove(trainee);
	        	return true;
	        }
			return false;
	     
	       
	
	}

	@Override
	public TraineeBean updatingTrainee(int traineeId,TraineeBean trainee) {
	
		trainee=(TraineeBean)entityManager.find(TraineeBean.class, traineeId);
        
        //Call remove method to remove the entity
		
        if(trainee != null && trainee.getTraineeId()==traineeId){
        	entityManager.merge(trainee);
        	
        }
		return trainee;
	
	
	
	}

}
