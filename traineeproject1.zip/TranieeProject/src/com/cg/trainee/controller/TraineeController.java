package com.cg.trainee.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.exceptions.TraineeException;
import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService service;
	
	 public ITraineeService getService() {
		return service;
	}

public void setService(ITraineeService service) {
		this.service = service;
	}


@RequestMapping("/showLoginPage")  
	 public String showLoginPage() {
			return "login";
		}
	
	
	
	
	 @RequestMapping("/login")  
	   
	    public String display(@RequestParam("uname") String uname,@RequestParam("pass") String pass,Model model)  
	    {  
		 System.out.println(uname+" "+pass);
	        if(uname.trim().equals("admin") && pass.equals("trainee"))  
	        {  
	          String msg="Logged in SuccessFully... \nHello "+ uname;  
	            
	           model.addAttribute("message", msg);  
	        }
	           else if(!(uname.trim().equals("admin") && pass.equals("trainee")))   
	         {
	        	   String msg="ENTER CORRECT USERNAME AND PASSWORD";
	        	   model.addAttribute("message",msg);
	        	   return "login";
	        }
	        return "tmsOperation"; 
	    }
	 
	 
	 @RequestMapping("/showTraineeform")
		public ModelAndView showaddtrainee() {
			
			TraineeBean trainee = new TraineeBean();
		
			return new ModelAndView("addTraineeform", "trainee", trainee);
		}
	 
	
	@RequestMapping("/addTrainee")
		public ModelAndView addDonation(@ModelAttribute("trainee") @Valid TraineeBean trainee,BindingResult result) throws TraineeException 
           {

			ModelAndView mv = null;
		

		//	System.out.println(result.hasErrors()+" "+"jjjjj");
			if (!result.hasErrors())
			{
				
				service.addTrainee(trainee);
				mv = new ModelAndView("successadding");
			/*	mv.addObject("traineeId", trainee.getTraineeId());
				mv.addObject("traineeName",trainee.getTraineeName());
				mv.addObject("traineeId", trainee.getTraineeDomain());
				mv.addObject("traineeName",trainee.getTraineeLocation());*/
			} else {
				mv = new ModelAndView("addTraineeform", "trainee", trainee); 
			}

			return mv;
		}
    
    @RequestMapping("/showMenu")  
	 public String showOperationpage() {
			return "tmsOperation";
		}
    
    
    
    @RequestMapping("/showAllTrainee")
	public ModelAndView showViewAllDonations()
    {

		ModelAndView mv = new ModelAndView();

		List<TraineeBean> list = service.getAllTraineeDetails();
		if (list.isEmpty()) {
			String msg = "There are no trainee";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		
    }
		else {
			mv.setViewName("viewAlltraineeList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
   
}
    
    @RequestMapping("/showaTraineeform")
	public ModelAndView showatrainee() {
		
		TraineeBean trainee = new TraineeBean();
	
		ModelAndView mv=new ModelAndView("viewtrainee", "trainee", trainee);
		 return mv;
	}
 

    @RequestMapping("/atrainee")
	public ModelAndView viewTrainee(@RequestParam("id") String ID,Model model) throws TraineeException {

		ModelAndView mv = new ModelAndView();
	
		
		TraineeBean trainee1 = new TraineeBean();
	
		int id2=Integer.parseInt(ID);
		trainee1 = service.getaTraineeDetails(id2);
		
		
      if (trainee1 != null) {
			mv.setViewName("viewtrainee");
			mv.addObject("trainee",trainee1);
		}
		else 
			mv.setViewName("login");
		return mv;
    }
    @RequestMapping("/delete")
  	public ModelAndView deleteatrainee() {
  		
  		TraineeBean trainee = new TraineeBean();
  	
  		return new ModelAndView("deletesuccess", "trainee", trainee);
  	}
    
    
    @RequestMapping("/deleteatrainee")
   	public ModelAndView deletetrainee(@RequestParam("id") String ID)
       {
    	ModelAndView mv; 
		int id2=Integer.parseInt(ID);
		
		
		if(service.deleteTrainee(id2))
			mv=new ModelAndView("tmsOperation","message","deleted successfully");
		
   		
		else {
			mv=new ModelAndView("deletesuccess","message","failed!!enter a valid id");
		}
   			
   			// Add the attribute to the model
   			return mv;
   		}
    @RequestMapping("/update")
  	public ModelAndView updateatrainee() {
  		
  		TraineeBean trainee = new TraineeBean();
  	
  		return new ModelAndView("updateTrainee", "trainee", trainee);
  	}
    @RequestMapping("/updateTrainee")
   	public ModelAndView updatetrainee(@ModelAttribute("trainee") @Valid TraineeBean trainee,BindingResult result)
       {
    	ModelAndView mv=null; 
		if(!result.hasErrors()) {
			
		
		service.updatingTrainee(trainee.getTraineeId(),trainee);
			mv=new ModelAndView("tmsOperation","message","updated successfully");
		}
   		
		else {
			mv=new ModelAndView("addTraineeform","trainee",trainee);
		}
   			
   			// Add the attribute to the model
   			return mv;
   		}
      
    
}



   


